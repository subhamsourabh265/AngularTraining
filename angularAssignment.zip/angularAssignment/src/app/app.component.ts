import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'advancedTraining';
  hideLeftPannel: any = false;
  showHide(event: Event): void {
    this.hideLeftPannel = !event;
  }
}
