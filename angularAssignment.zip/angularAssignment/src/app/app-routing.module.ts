import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'floatingBanner',
    loadChildren: () => import('./modules/floating-banner/floating-banner.module').then(
      m => m.FloatingBannerModule
    )
  },
  {
    path: 'ecom',
    loadChildren: () => import('./modules/e-commerce/e-commerce.module').then(
      m => m.ECommerceModule
    )
  },
  {
    path: 'ctimer1',
    loadChildren: () => import('./modules/countdown-timer/countdown-timer.module').then(
      m => m.CountdownTimerModule
    )
  },
  {
    path: 'ctimer2',
    loadChildren: () => import('./modules/countdown-timer-service/countdown-timer-service.module').then(
      m => m.CountdownTimerServiceModule
    )
  },
  {
    path: 'dynamicTable',
    loadChildren: () => import('./modules/dynamic-table/dynamic-table.module').then(
      m => m.DynamicTableModule
    )
  },
  {
    path: 'dynamicBox',
    loadChildren: () => import('./modules/dynamic-box/dynamic-box.module').then(
      m => m.DynamicBoxModule
    )
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
