import { Component, OnInit } from '@angular/core';
import { HEADERLABELS } from '../../app-settings.config';


@Component({
  selector: 'ss-app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  headerLabels: {heading: string} = HEADERLABELS;
  constructor() { }
  

  ngOnInit(): void {
    // this.headerLabels = HEADERLABELS;
  }

}
