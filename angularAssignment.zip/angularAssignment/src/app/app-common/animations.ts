import { animate, style, transition } from "@angular/animations";

export const leftPanelAnimation = [
  transition(':enter', [
    style({ opacity: 0, transform: 'translateX(-100%)' }),
    animate('0.5s', style({ opacity: 1, transform: 'translateX(0)' })),
  ]),
  transition(':leave', [
    animate('0.5s', style({ opacity: 0, transform: 'translateX(-100%)' })),
  ]),
];

export const bannerAnimation = [
  transition(':enter', [
    style({ opacity: 1, transform: 'translateX(-100%)' }),
    animate('4s', style({ opacity: 1, transform: 'translateX(0)' })),
  ]),
  transition(':leave', [
    animate('4s', style({ opacity: 1, transform: 'translateX(100%)' })),
  ]),
];

export const bannerRotate = [
  transition(':enter', [
    style({ opacity: 1, transform: 'rotate(0deg)' }),
    animate('4s', style({ opacity: 1, transform: 'rotate(360deg)' })),
  ]),
  transition(':leave', [
    animate('4s', style({ opacity: 1, transform: 'rotate(0deg)' })),
  ]),
];

export const dynamicDiv = [
  transition(':enter', [
    style({ opacity: 1, transform: 'translateX(-200%)' }),
    animate('0.5s', style({ opacity: 1, transform: 'translateX(0)' })),
  ]),
  transition(':leave', [
    animate('0.5s', style({ opacity: 1, transform: 'translateX(100%)' })),
  ]),
];