export interface timerLog {
    status: string;
    timeStamp: string;
}

export interface timerCount {
    startCount: number;
    pauseCount: number;
}