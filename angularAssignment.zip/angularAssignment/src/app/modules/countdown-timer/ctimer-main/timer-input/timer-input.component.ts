import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { TIMERLABELS } from 'src/app/app-common/app-settings.config';
import { timerCount, timerLog } from 'src/app/app-common/models';

@Component({
  selector: 'ss-app-timer-input',
  templateUrl: './timer-input.component.html',
  styleUrls: ['./timer-input.component.scss']
})
export class TimerInputComponent implements OnInit, OnDestroy {

  @Output() timerEvent: EventEmitter<number> = new EventEmitter<number>();
  @Output() timerLogEvent: EventEmitter<timerLog> = new EventEmitter<timerLog>();
  @Output() timerCountEvent: EventEmitter<timerCount> = new EventEmitter<timerCount>();
  timerLabels = TIMERLABELS;
  timerInput = 0;
  timerValue = this.timerInput;
  timerStatus: string = '';
  timeStamp: any;
  pausedAt: number = 0;
  startCount: number = 0;
  pauseCount: number = 0;
  timer: any;
  logItems: number[] = [];
  showLogs = false;
  constructor() { }

  ngOnInit(): void {

  }

  startTimer(): void {
    if (this.timerStatus) {
      if (this.timerStatus === 'started') {
        this.timerStatus = 'paused';
        this.pauseCount++;
        if (this.timerValue > 0) {
          this.logItems.push(this.timerValue);
        }
        this.showLogs = !!this.logItems.length;
        clearInterval(this.timer);
      } else {
        this.timerStatus = 'started';
        this.startCount++;
        this.timer = setInterval(() => {
          this.timerValue--;
          if (this.timerValue >= 0) {
            this.timerEvent.emit(this.timerValue);
          }
          if (this.timerValue <= 0) {
            clearInterval(this.timer);
          }
        }, 1000);
      }
    } else {
      this.timerValue = this.timerInput;
      this.timerStatus = 'started';
      this.startCount++;
      this.timer = setInterval(() => {
        this.timerValue--;
        if (this.timerValue >= 0) {
          this.timerEvent.emit(this.timerValue);
        }
        if (this.timerValue <= 0) {
          clearInterval(this.timer);
        }
      }, 1000);
    }
    if (this.timerValue > 0) {
      this.timerLogEvent.emit({
        status: this.timerStatus,
        timeStamp: new Date().toLocaleString()
      });
      this.timerCountEvent.emit({
        startCount: this.startCount,
        pauseCount: this.pauseCount
      });
    }
    
  }

  resetTimer(): void {
    this.timerStatus = '';
    this.timerValue = 0;
    this.timerInput = 0;
    this.startCount = 0;
    this.pauseCount = 0;
    this.logItems = [];
    this.showLogs = false;
    this.timerEvent.emit(this.timerValue);
    this.timerLogEvent.emit({
      status: this.timerStatus,
      timeStamp: new Date().toLocaleString()
    });
    this.timerCountEvent.emit({
      startCount: this.startCount,
      pauseCount: this.pauseCount
    });
    clearInterval(this.timer);
  }

  ngOnDestroy(): void {
    clearInterval(this.timer);
  }

}
