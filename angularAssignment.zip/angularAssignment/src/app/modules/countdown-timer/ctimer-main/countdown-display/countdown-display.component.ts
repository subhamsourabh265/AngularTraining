import { Component, Input, OnInit } from '@angular/core';
import { TIMERLABELS } from 'src/app/app-common/app-settings.config';

@Component({
  selector: 'ss-app-countdown-display',
  templateUrl: './countdown-display.component.html',
  styleUrls: ['./countdown-display.component.scss']
})
export class CountdownDisplayComponent implements OnInit {

  @Input() timerValue: number = 1500;
  timerLabels = TIMERLABELS;
  constructor() { }

  ngOnInit(): void {
  }

}
