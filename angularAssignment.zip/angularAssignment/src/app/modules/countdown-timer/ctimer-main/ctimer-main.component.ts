import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ss-app-ctimer-main',
  templateUrl: './ctimer-main.component.html',
  styleUrls: ['./ctimer-main.component.scss']
})
export class CtimerMainComponent implements OnInit {

  timerValue: number = 0;
  timeCounter = [];
  timeLogger = [];
  timerStatus: string = '';
  timeStamp: string = '';
  startCount: number = 0;
  pauseCount: number = 0;
  constructor() { }

  ngOnInit(): void {
  }

  updateTimer(event: any): void {
    this.timerValue = event;
  }

  logTime(event: any): void {
    this.timerStatus = event.status;
    this.timeStamp = event.timeStamp;
  }

  countClicks(event: any): void {
    this.startCount = event.startCount;
    this.pauseCount = event.pauseCount;
  }

}
