import { trigger } from '@angular/animations';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { bannerAnimation, bannerRotate } from 'src/app/app-common/animations';
import { BANNERLABELS } from 'src/app/app-common/app-settings.config';

@Component({
  selector: 'ss-app-floating-banner-main',
  templateUrl: './floating-banner-main.component.html',
  styleUrls: ['./floating-banner-main.component.scss'],
  animations: [trigger('rotatingBanner', bannerRotate)] //bannerAnimation
})
export class FloatingBannerMainComponent implements OnInit, OnDestroy{

  bannerLabels = BANNERLABELS;
  showBanner = true;
  bannerInterval: any;
  constructor() { }

  ngOnInit(): void {
    this.bannerInterval = setInterval(() => {
      this.showBanner = !this.showBanner;
    }, 2000)
  }

  ngOnDestroy(): void {
    clearInterval(this.bannerInterval);
  }

}
