import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'ss-app-alert-box',
  templateUrl: './alert-box.component.html',
  styleUrls: ['./alert-box.component.scss']
})
export class AlertBoxComponent implements OnInit {

  @Output() closeAlertBox = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  closeAlert(): void {
    this.closeAlertBox.emit('');
  }

}
