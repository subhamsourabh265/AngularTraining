import { trigger } from '@angular/animations';
import { AfterViewInit, Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { dynamicDiv } from 'src/app/app-common/animations';

@Component({
  selector: 'ss-app-dynamic-div-main',
  templateUrl: './dynamic-div-main.component.html',
  styleUrls: ['./dynamic-div-main.component.scss'],
  animations: [trigger('openDiv', dynamicDiv)]
})
export class DynamicDivMainComponent implements OnInit, OnDestroy {

  isAnimate = false;
  setTimer: any;
  showAlert = false;
  clickedDiv: string = '';
  dynamicBoxes: string[] = ['box', 'box', 'box'];
  constructor() { }

  ngOnInit(): void {
  }

  showAlertBox(index: number) {
    console.log(index);
    const lastChar = index.toString().charAt(index.toString().length-1)
    this.showAlert = true;
    if(index >= 4 && index <= 20) {
      this.clickedDiv = `${index}th`;
    } else if(lastChar === '1'){
      this.clickedDiv = `${index}st`;
    } else if (lastChar === '2') {
      this.clickedDiv = `${index}nd`;
    } else if (lastChar === '3') {
      this.clickedDiv = `${index}rd`;
    } else {
      this.clickedDiv = `${index}th`;
    }
  }

  itemById(index: any, item: any) {
    return item.name;
  }

  onScroll(event: any) {
      if(event.target.scrollTop >= event.target.scrollHeight-event.target.offsetHeight){
        this.isAnimate = true;
        this.setTimer = setTimeout(() => {
          this.dynamicBoxes.push('Box');
          clearTimeout(this.setTimer);
        },1000);        
      }
  }

  ngOnDestroy(): void {
    clearTimeout(this.setTimer);
  }

}
